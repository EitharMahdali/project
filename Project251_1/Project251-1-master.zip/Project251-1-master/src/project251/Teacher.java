
package project251;

public class Teacher {
private  String [ ] Class;
private String [ ] Level;
private  int [ ] StudentsGrade;
private Student StudentU;

    public Teacher(String[] Class, String[] Level, int[] StudentsGrade, Student StudentU) {
        this.Class = Class;
        this.Level = Level;
        this.StudentsGrade = StudentsGrade;
        this.StudentU = StudentU;
    }

    public Teacher() {
    }
public int ShowGrade( String FirstName, String LastName){
     return -1;
} 
public String ShowReport( Student [ ] Student){
    return"r";
}
    }   

