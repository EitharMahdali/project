
package project251;

public class User {
    private int SSN;
    private String password;
    private String FName;
    private String LName;
    private String level;
    private String section;
    
    
    
    public void Login(int SSN,String password){
        
    }
    
}
